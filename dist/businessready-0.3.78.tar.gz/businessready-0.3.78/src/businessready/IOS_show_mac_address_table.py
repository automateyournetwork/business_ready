# import sys
# from .brd import IOS_show_mac_address_table
# def run():
#     print(IOS_show_mac_address_table(sys.argv[1]))