# import sys
# from .brd import IOS_learned_ospf
# def run():
#     print(IOS_learned_ospf(sys.argv[1]))