# import sys
# from .brd import IOS_show_environment_all
# def run():
#     print(IOS_show_environment_all(sys.argv[1]))