import sys
from .brd import DNAC_Sites
def run():
    print(DNAC_Sites(sys.argv[1]))