# import sys
# from .brd import NXOS_learn_acl
# def run():
#     print(NXOS_learn_acl(sys.argv[1]))