# import sys
# from .brd import IOS_learn_stp
# def run():
#     print(IOS_learn_stp(sys.argv[1]))