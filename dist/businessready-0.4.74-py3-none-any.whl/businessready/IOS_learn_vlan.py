# import sys
# from .brd import IOS_learn_vlan
# def run():
#     print(IOS_learn_vlan(sys.argv[1]))