# import sys
# from .brd import DNAC_routing_topology
# def run():
#     print(DNAC_routing_topology(sys.argv[1]))