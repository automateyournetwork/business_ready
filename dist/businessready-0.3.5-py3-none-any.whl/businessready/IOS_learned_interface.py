import sys
from .brd import IOS_learned_interface
def run():
    print(IOS_learned_interface(sys.argv[1]))