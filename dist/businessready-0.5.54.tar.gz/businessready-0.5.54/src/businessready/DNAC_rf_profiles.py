# import sys
# from .brd import DNAC_rf_profiles
# def run():
#     print(DNAC_rf_profiles(sys.argv[1]))