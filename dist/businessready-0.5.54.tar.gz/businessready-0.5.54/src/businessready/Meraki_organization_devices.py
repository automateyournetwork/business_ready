# import sys
# from .brd import Meraki_organization_devices
# def run():
#     print(Meraki_organization_devices(sys.argv[1]))