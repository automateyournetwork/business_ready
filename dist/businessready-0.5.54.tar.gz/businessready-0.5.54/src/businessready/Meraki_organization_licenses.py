# import sys
# from .brd import Meraki_organization_licenses
# def run():
#     print(Meraki_organization_licenses(sys.argv[1]))