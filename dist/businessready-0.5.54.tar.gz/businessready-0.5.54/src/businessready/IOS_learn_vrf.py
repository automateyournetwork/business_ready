# import sys
# from .brd import IOS_learn_vrf
# def run():
#     print(IOS_learn_vrf(sys.argv[1]))