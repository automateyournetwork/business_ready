# import sys
# from .brd import IOS_show_ip_ospf_interface
# def run():
#     print(IOS_show_ip_ospf_interface(sys.argv[1]))