# import sys
# from .brd import IOS_learned_vlan
# def run():
#     print(IOS_learned_vlan(sys.argv[1]))