import sys
from .brd import IOS_learned_routing
def run():
    print(IOS_learned_routing(sys.argv[1]))