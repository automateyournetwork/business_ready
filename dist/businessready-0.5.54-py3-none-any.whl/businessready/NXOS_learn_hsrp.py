# import sys
# from .brd import NXOS_learn_hsrp
# def run():
#     print(NXOS_learn_hsrp(sys.argv[1]))