# import sys
# from .brd import DNAC_physical_topology
# def run():
#     print(DNAC_physical_topology(sys.argv[1]))