# import sys
# from .brd import Meraki_organizations
# def run():
#     print(Meraki_organizations(sys.argv[1]))