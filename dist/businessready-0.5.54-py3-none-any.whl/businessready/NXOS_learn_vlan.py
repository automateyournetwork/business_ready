# import sys
# from .brd import NXOS_learn_routing
# def run():
#     print(NXOS_learn_routing(sys.argv[1]))