# import sys
# from .brd import DNAC_projects
# def run():
#     print(DNAC_projects(sys.argv[1]))