# import sys
# from .brd import DNAC_network_health
# def run():
#     print(DNAC_network_health(sys.argv[1]))