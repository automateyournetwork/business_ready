# import sys
# from .brd import IOS_learn_ntp
# def run():
#     print(IOS_learn_ntp(*sys.argv[1:4]))

# if __name__ == "__main__":
#     run()