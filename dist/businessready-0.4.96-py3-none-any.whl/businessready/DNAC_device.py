# import sys
# from .brd import DNAC_device
# def run():
#     print(DNAC_device(sys.argv[1]))