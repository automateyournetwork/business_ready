# import sys
# from .brd import IOS_learn_hsrp
# def run():
#     print(IOS_learn_hsrp(sys.argv[1]))