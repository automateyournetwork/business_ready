# import sys
# from .brd import DNAC_sites
# def run():
#     print(DNAC_sites(sys.argv[1]))