# import sys
# from .brd import NXOS_learn_bgp
# def run():
#     print(NXOS_learn_bgp(*sys.argv[1:4]))

# if __name__ == "__main__":
#     run()