# import sys
# from .brd import IOS_learned_lldp
# def run():
#     print(IOS_learned_lldp(*sys.argv[1:4]))

# if __name__ == "__main__":
#     run()