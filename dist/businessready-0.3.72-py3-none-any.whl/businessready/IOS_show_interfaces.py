# import sys
# from .brd import IOS_show_interfaces
# def run():
#     print(IOS_show_interfaces(sys.argv[1]))