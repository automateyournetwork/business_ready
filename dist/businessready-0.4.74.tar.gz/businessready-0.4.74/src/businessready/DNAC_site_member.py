# import sys
# from .brd import DNAC_site_member
# def run():
#     print(DNAC_site_member(sys.argv[1]))