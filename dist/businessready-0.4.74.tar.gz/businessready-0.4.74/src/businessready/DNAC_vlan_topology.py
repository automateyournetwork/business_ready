# import sys
# from .brd import DNAC_vlan_topology
# def run():
#     print(DNAC_vlan_topology(sys.argv[1]))