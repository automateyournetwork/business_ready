# import sys
# from .brd import NXOS_learn_vrf
# def run():
#     print(NXOS_learn_vrf(sys.argv[1]))