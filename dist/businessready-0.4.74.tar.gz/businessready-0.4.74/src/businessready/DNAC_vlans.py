# import sys
# from .brd import DNAC_vlans
# def run():
#     print(DNAC_vlans(sys.argv[1]))