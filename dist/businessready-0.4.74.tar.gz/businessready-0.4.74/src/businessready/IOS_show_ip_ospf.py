# import sys
# from .brd import IOS_show_ip_ospf
# def run():
#     print(IOS_show_ip_ospf(sys.argv[1]))