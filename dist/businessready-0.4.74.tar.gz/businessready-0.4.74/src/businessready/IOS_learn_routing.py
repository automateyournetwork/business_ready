# import sys
# from .brd import IOS_learn_routing
# def run():
#     print(IOS_learn_routing(sys.argv[1]))