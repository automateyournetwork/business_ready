# import sys
# from .brd import NXOS_learn_platform
# def run():
#     print(NXOS_learn_platform(sys.argv[1]))