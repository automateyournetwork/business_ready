# import sys
# from .brd import NXOS_learn_vlan
# def run():
#     print(NXOS_learn_vlan(sys.argv[1]))