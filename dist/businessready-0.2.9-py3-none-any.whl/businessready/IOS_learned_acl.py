import sys
from .brd import IOS_learned_acl
def run():
    print(IOS_learned_acl(sys.argv[1]))