# import sys
# from .brd import IOS_show_ip_ospf_neighbor
# def run():
#     print(IOS_show_ip_ospf_neighbor(sys.argv[1]))