# import sys
# from .brd import IOS_learn_lldp
# def run():
#     print(IOS_learn_lldp(*sys.argv[1:4]))

# if __name__ == "__main__":
#     run()