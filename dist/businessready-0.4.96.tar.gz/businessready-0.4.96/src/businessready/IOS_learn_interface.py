# import sys
# from .brd import IOS_learn_interface
# def run():
#     print(IOS_learn_interface(sys.argv[1]))