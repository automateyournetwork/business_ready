# import sys
# from .brd import IOS_learn_ospf
# def run():
#     print(IOS_learn_ospf(sys.argv[1]))