# import sys
# from .brd import DNAC_site_health
# def run():
#     print(DNAC_site_health(sys.argv[1]))