# import sys
# from .brd import DNAC_templates
# def run():
#     print(DNAC_templates(sys.argv[1]))