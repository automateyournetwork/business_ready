# import sys
# from .brd import NXOS_learn_ospf
# def run():
#     print(NXOS_learn_ospf(sys.argv[1]))