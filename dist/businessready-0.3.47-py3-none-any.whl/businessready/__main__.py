# import sys
# from .brd import IOS_learned_acl,IOS_learned_arp,IOS_learned_dot1x,IOS_learned_interface,IOS_learned_lldp,IOS_learned_ntp,IOS_learned_ospf,IOS_learned_routing,IOS_learned_stp,IOS_learned_vlan,IOS_learned_vrf,IOS_show_ip_interface_brief,DNAC_Sites
# if __name__ == "__main__":
#     print(IOS_learned_acl(sys.argv[4]))
#     print(IOS_learned_arp(sys.argv[4]))
#     print(IOS_learned_dot1x(sys.argv[4]))
#     print(IOS_learned_interface(sys.argv[4]))
#     print(IOS_learned_lldp(sys.argv[4]))
#     print(IOS_learned_ospf(sys.argv[4]))
#     print(IOS_learned_routing(sys.argv[4]))
#     print(IOS_learned_stp(sys.argv[4]))
#     print(IOS_learned_vlan(sys.argv[4]))
#     print(IOS_learned_vrf(sys.argv[4]))
#     print(IOS_show_ip_interface_brief(sys.argv[4]))
#     print(DNAC_Sites(sys.argv[2]))