# import sys
# from .brd import IOS_learned_bgp
# def run():
#     print(IOS_learned_bgp(*sys.argv[1:4]))

# if __name__ == "__main__":
#     run()