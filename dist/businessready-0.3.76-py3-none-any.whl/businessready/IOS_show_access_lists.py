# import sys
# from .brd import IOS_show_access_lists
# def run():
#     print(IOS_show_access_lists_brief(sys.argv[1]))