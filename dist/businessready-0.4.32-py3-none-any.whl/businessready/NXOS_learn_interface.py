# import sys
# from .brd import NXOS_learn_interface
# def run():
#     print(NXOS_learn_interface(sys.argv[1]))