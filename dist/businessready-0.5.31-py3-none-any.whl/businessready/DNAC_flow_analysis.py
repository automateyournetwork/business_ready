# import sys
# from .brd import DNAC_flow_analysis
# def run():
#     print(DNAC_flow_analysis(sys.argv[1]))