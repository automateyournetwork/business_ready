# import sys
# from .brd import IOS_show_interfaces_trunk
# def run():
#     print(IOS_show_interfaces_trunk(sys.argv[1]))