# import sys
# from .brd import IOS_show_ntp_associations
# def run():
#     print(IOS_show_ntp_associations(sys.argv[1]))