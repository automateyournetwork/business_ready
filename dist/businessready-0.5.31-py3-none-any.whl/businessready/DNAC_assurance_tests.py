# import sys
# from .brd import DNAC_assurance_tests
# def run():
#     print(DNAC_assurance_tests(sys.argv[1]))