# import sys
# from .brd import IOS_show_interfaces_status
# def run():
#     print(IOS_show_interfaces_status(sys.argv[1]))