# import sys
# from .brd import IOS_show_cdp_neighbors_details
# def run():
#     print(IOS_show_cdp_neighbors_details(sys.argv[1]))