# import sys
# from .brd import IOS_show_inventory_9000
# def run():
#     print(IOS_show_inventory_9000(sys.argv[1]))