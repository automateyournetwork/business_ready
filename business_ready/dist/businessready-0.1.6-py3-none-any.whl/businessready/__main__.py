import sys
from .brd import IOS_learned_interface
if __name__ == "__main__":
    print(IOS_learned_interface(sys.argv[1]))